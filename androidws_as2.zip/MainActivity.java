package com.example.chandanachakilam.assignment2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int mcount = 1;
    private TextView showCount ;
    private TextView showTotal;
    private float total=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void countDown(View view) {
     showCount = (TextView)findViewById(R.id.count);
     if(mcount>0){
        mcount--;
         if(showCount!= null)
         {
             showCount.setText(Integer.toString(mcount));
         }
         if(mcount<=0)
         {
             showCount.setText("0");
             mcount = 0;
         }
                }

    }

    public void countUp(View view) {

        showCount = (TextView)findViewById(R.id.count);
        mcount++;
        if(showCount!=null)
            showCount.setText(Integer.toString(mcount));

    }

    public void buy(View view) {
        showTotal = (TextView)findViewById(R.id.total);
        total = (float)(4.20 * mcount);
        showTotal.setText(Float.toString(total));
        }

    }

