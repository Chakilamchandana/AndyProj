package com.example.chandanachakilam.assignment_3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void launchSecondActivitya(View view) {
        Intent i = new Intent(this, SecondActivity.class);
        startActivity(i);
    }

    public void launchSecondActivityb(View view) {
        Intent j = new Intent(this,second2Activity.class);
        startActivity(j);
    }

    public void launchSecondActivityc(View view) {
        Intent k = new Intent(this,Second3Activity.class);
        startActivity(k);
    }
}
