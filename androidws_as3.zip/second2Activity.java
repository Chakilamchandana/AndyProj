package com.example.chandanachakilam.assignment_3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class second2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second2);
    }
}
