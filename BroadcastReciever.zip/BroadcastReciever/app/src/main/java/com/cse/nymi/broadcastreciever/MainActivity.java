package com.cse.nymi.broadcastreciever;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private static final String CUSTOM_BROADCAST="com.cse.nymi.broadcastreciever.MainActivity";
    MyReceiver myreciever = new MyReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LocalBroadcastManager.getInstance(this).registerReceiver(myreciever, new IntentFilter(CUSTOM_BROADCAST));
    }
    public void send(View view)
    {
        Intent customBroadcastIntent = new Intent(CUSTOM_BROADCAST);
        LocalBroadcastManager.getInstance(this).sendBroadcast(customBroadcastIntent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(myreciever);
    }
}
