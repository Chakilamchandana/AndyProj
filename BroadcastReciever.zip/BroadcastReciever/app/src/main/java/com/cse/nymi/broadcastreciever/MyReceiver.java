package com.cse.nymi.broadcastreciever;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {
 private final String CUSTOM_BROADCAST="com.cse.nymi.broadcastreciever.MainActivity";
    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.

        String action=intent.getAction();

        switch (action)
        {
            case Intent.ACTION_AIRPLANE_MODE_CHANGED:
                Toast.makeText(context,"Mode Changed", Toast.LENGTH_LONG).show();
                break;
            case Intent.ACTION_CAMERA_BUTTON:
                Toast.makeText(context,"You Clicked Camera", Toast.LENGTH_LONG).show();
                break;
            case CUSTOM_BROADCAST:
                Toast.makeText(context, "you clicked ", Toast.LENGTH_LONG).show();
        }
    }
}
