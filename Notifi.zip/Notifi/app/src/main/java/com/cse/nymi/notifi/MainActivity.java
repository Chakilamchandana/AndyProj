package com.cse.nymi.notifi;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    NotificationManager rm;
    NotificationCompat.Builder builder;
int NOTIFICATION_ID=0;


    PendingIntent pi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    }

    public void notify(View view)
    {
        Intent intent=new Intent(String.valueOf(MainActivity.this));
        pi=PendingIntent.getActivity(MainActivity.this,NOTIFICATION_ID,intent,PendingIntent.FLAG_UPDATE_CURRENT);

        builder=new NotificationCompat.Builder(this);
        builder.setContentTitle("Wake up..!!");
        builder.setContentText("it is not the time to sleep.!");
        //builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setContentIntent(pi);
        builder.setSound(Uri.parse("android.resource://com.cse.nymi.notifi"));
        rm.notify(NOTIFICATION_ID,builder.build());
    }

}
