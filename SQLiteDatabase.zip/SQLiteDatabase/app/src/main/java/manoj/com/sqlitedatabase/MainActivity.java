package manoj.com.sqlitedatabase;

import android.content.ContentValues;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText et_name,et_age;
    DatabaseHelper databaseHelper;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_name = (EditText)findViewById(R.id.tv1);
        et_age = (EditText)findViewById(R.id.tv2);
        databaseHelper = new DatabaseHelper(MainActivity.this);
        result = (TextView)findViewById(R.id.textView);
    }

    public void saveData(View view) {
        String name = et_name.getText().toString();
        int age = Integer.parseInt(et_age.getText().toString());
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_1,name);
        values.put(DatabaseHelper.COLUMN_2,age);

        long i = databaseHelper.insertData(values);
        if (i!=-1)
        {
            Toast.makeText(this, i+" ROW INSERTED", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, i+"INSERTION FAILED", Toast.LENGTH_SHORT).show();
        }
    }

    public void retrieveData(View view) {
        Cursor c = databaseHelper.retrieveData();
        if(c!=null){
            StringBuffer sb = new StringBuffer();
            c.moveToFirst();
            do {
                sb.append(c.getString(1)+":"+c.getInt(2)+"\n");
            }while (c.moveToNext());
            result.setText(sb.toString());
        }
        else {
            Toast.makeText(this, "No information is retrieved", Toast.LENGTH_SHORT).show();
        }
    }
}
