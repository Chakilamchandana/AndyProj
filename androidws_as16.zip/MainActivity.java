package com.example.chandanachakilam.assignment16;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showToast1(View view) {
        Toast t1 = Toast.makeText(this,"Check Box 1",Toast.LENGTH_SHORT);
        t1.show();

    }

    public void showToast2(View view) {
        Toast t2 = Toast.makeText(this,"Check Box 2",Toast.LENGTH_SHORT);
        t2.show();

    }

    public void showToast3(View view) {
        Toast t3 = Toast.makeText(this,"Check Box 3",Toast.LENGTH_SHORT);
        t3.show();

    }

    public void showToast4(View view) {
        Toast t4 = Toast.makeText(this,"Check Box 4",Toast.LENGTH_SHORT);
        t4.show();

    }

    public void showToast5(View view) {
        Toast t5 = Toast.makeText(this,"Check Box 5",Toast.LENGTH_SHORT);
        t5.show();

    }
}
