package com.cse.sai.implicitindex;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText et1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText) findViewById(R.id.et);
    }

    public void sower(View view) {
        String data=et1.getText().toString();
        Uri u=Uri.parse("tel:"+data);
        Intent i=new Intent(Intent.ACTION_CALL,u);
        startActivity(i);

    }
    public void showweb(View View){
        String data=et1.getText().toString();
        Uri u=Uri.parse("http://"+data);
        Intent i=new Intent(Intent.ACTION_VIEW,u);
        startActivity(i);
    }
    public  void showlocation(View view){
        String data=et1.getText().toString();
        Uri u=Uri.parse("geo:0,0?q="+data);
        Intent i=new Intent(Intent.ACTION_VIEW,u);
        startActivity(i);
    }
}
