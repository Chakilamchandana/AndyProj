package manoj.com.sharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SecondScreen extends AppCompatActivity {


    EditText username,userpass,userplace,usergender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);


        username= (EditText)findViewById(R.id.Edit_User);
        userpass=(EditText)findViewById(R.id.Edit_Pass);
        userplace= (EditText)findViewById(R.id.Edit_Place);
        usergender=(EditText)findViewById(R.id.Edit_Gender);
    }

    public void SaveData(View view) {

        SharedPreferences spf =getSharedPreferences("myspf",MODE_PRIVATE);
        SharedPreferences.Editor editor = spf.edit();


        editor.putString("Name",username.getText().toString());
        editor.putString("password",userpass.getText().toString());
        editor.putString("place",userplace.getText().toString());
        editor.putString("gender",usergender.getText().toString());
        editor.apply();


        Toast.makeText(this, "sucessfully saved", Toast.LENGTH_SHORT).show();
        finish();

    }

}
