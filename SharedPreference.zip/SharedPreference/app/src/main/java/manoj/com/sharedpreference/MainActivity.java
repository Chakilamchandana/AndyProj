package manoj.com.sharedpreference;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {

    EditText Uname,Upass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      Uname= (EditText)findViewById(R.id.Edit_Login);
        Upass=(EditText)findViewById(R.id.et1);



    }

    public void Loginname(View view) {

        SharedPreferences spf = getSharedPreferences("myspf",MODE_PRIVATE);
        String sp_username = spf.getString("Name",null);
        String sp_pass = spf.getString("password",null);
        String u_username = Uname.getText().toString();
        String u_password = Upass.getText().toString();
        if (u_username.equals(sp_username)&&u_password.equals(sp_pass))
        {
            Toast.makeText(this, "credentials matched", Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(this, "credentials not found", Toast.LENGTH_SHORT).show();
        }

    }

    public void register(View view) {

        Intent i =new Intent(MainActivity.this,SecondScreen.class);
        startActivity(i);


    }
}
