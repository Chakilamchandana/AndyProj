package manoj.com.jobscheduler;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
JobScheduler js ;
    JobInfo.Builder builder;
    int JOB_ID=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        js = (JobScheduler)getSystemService(JOB_SCHEDULER_SERVICE);

    }

    public void schedule(View view) {

        builder =new JobInfo.Builder(JOB_ID,new ComponentName(getPackageName(),MyJobService.class.getName()));
       // builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
        builder.setRequiresCharging(true);
        js.schedule(builder.build());


    }
}
