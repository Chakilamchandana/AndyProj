package apssdc.in.asyncweatherapi;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Prabhu Kumari on 03-02-2018.
 */

class FetchWeatherReport extends AsyncTask<String, Void, String> {
    MainActivity mainActivity;
    TextView result;
    ProgressDialog progressDialog;
    public FetchWeatherReport(MainActivity mainActivity, TextView tv) {
    this.mainActivity=mainActivity;
    this.result=tv;
        progressDialog=new ProgressDialog(mainActivity);
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progressDialog.setMessage("Connecting to Internet...Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    @Override
    protected String doInBackground(String... strings) {
        String loc=strings[0];
        String link="https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22"+loc+"%2C%20ak%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";

        try {
            URL url=new URL(link);
            HttpURLConnection connection=(HttpURLConnection)url.openConnection();
            connection.setRequestMethod("GET");
            InputStream inputStream=connection.getInputStream();
            if(inputStream==null)
            {
                return "No data found";
            }
            InputStreamReader inputStreamReader=new InputStreamReader(inputStream);
            BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
            StringBuffer buffer=new StringBuffer();
            String line="";
            while((line=bufferedReader.readLine())!=null) {

                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        progressDialog.cancel();
        try {
            JSONObject parentObj=new JSONObject(s);
            JSONObject queryObj=parentObj.getJSONObject("query");
            JSONObject resultsObj=queryObj.getJSONObject("results");
            JSONObject channelObj=resultsObj.getJSONObject("channel");
            JSONObject locationObj=channelObj.getJSONObject("location");
            String city=locationObj.getString("city");
            JSONObject itemObj=channelObj.getJSONObject("item");
            JSONObject conditionObj=itemObj.getJSONObject("condition");
            String temperature=conditionObj.getString("temp");
            result.setText(city+": "+temperature);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
